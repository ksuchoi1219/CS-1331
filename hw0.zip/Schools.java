public class Schools {
    public static void main(String[] args) {
        String gt = "Georgia Institute of Technology";
        System.out.printf("%s > %s%n", gt, uga);
    }
}
